<?php /* Smarty version Smarty-3.1.15, created on 2016-03-10 10:46:33
         compiled from "D:\xampp\htdocs\araam\presentation\templates\adminfooter.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1257156e10a39e7b239-26211529%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '91d182ddee50b952dcdddcfc7a78f4b9c5a2164a' => 
    array (
      0 => 'D:\\xampp\\htdocs\\araam\\presentation\\templates\\adminfooter.tpl',
      1 => 1456294439,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1257156e10a39e7b239-26211529',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_56e10a39e92933_58503091',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e10a39e92933_58503091')) {function content_56e10a39e92933_58503091($_smarty_tpl) {?>    <!--div class="row">
        <div class="col-md-6">
            <p>
                &copy; 2015 Araam.pk All Rights Reserved.
            </p>
        </div>
        <div class="col-md-6">
            <p>
                Admin
            </p>
        </div>
    </div-->
</div>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="<?php echo $_smarty_tpl->getConfigVariable('site_root');?>
/web/js/jquery.js"></script>
<script src="<?php echo $_smarty_tpl->getConfigVariable('site_root');?>
/web/js/bootstrap.js"></script>
<script src="offcanvas.js"></script>
<script src="<?php echo $_smarty_tpl->getConfigVariable('site_root');?>
/web/js/parsley.js" type="text/javascript" ></script>
</body>
</html><?php }} ?>
