<?php /* Smarty version Smarty-3.1.15, created on 2016-03-10 09:42:55
         compiled from "D:\xampp\htdocs\araam\presentation\templates\contractorleftbar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1061156e0fb4ff19d41-48155685%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '31d56a8ac136514d6a25691c92093ef5a04e0cba' => 
    array (
      0 => 'D:\\xampp\\htdocs\\araam\\presentation\\templates\\contractorleftbar.tpl',
      1 => 1456295179,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1061156e0fb4ff19d41-48155685',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_56e0fb4ff2d5c1_84930773',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e0fb4ff2d5c1_84930773')) {function content_56e0fb4ff2d5c1_84930773($_smarty_tpl) {?><h3>Contractor Guidelines</h3>
<p>Cras ornare vulputate velit a luctus. Nam molestie gravida dolor. Maecenas consectetur est bibendum, varius justo et, aliquet justo. Aliquam eget felis eget risus rhoncus pellentesque in at dui. Nunc rhoncus semper nibh vel pharetra. Duis nibh quam, bibendum nec consequat eget, egestas eget urna. Vivamus sit amet convallis dui. Sed a dui vel erat dapibus dictum ac eget elit. Curabitur mollis turpis vel lorem pretium consequat. Nunc elementum augue quis tempor sodales. Aenean eleifend risus nec tellus suscipit dictum. Nunc aliquet nec orci sit amet ultrices. Aliquam ultrices dolor at risus tristique, vitae feugiat justo hendrerit.</p><?php }} ?>
