<?php /* Smarty version Smarty-3.1.15, created on 2016-03-10 09:37:28
         compiled from "D:\xampp\htdocs\araam\presentation\templates\leftbar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2108556e0fa085d3da9-18654173%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '12dcf254d6a7bf4b04fdf0c6eafc37b2a20cd665' => 
    array (
      0 => 'D:\\xampp\\htdocs\\araam\\presentation\\templates\\leftbar.tpl',
      1 => 1457444729,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2108556e0fa085d3da9-18654173',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_56e0fa08606a22_65280930',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e0fa08606a22_65280930')) {function content_56e0fa08606a22_65280930($_smarty_tpl) {?><h3>Important Links</h3>

<p>We can put some slides or instructions here for users. <br /><br />Cras ornare vulputate velit a luctus. Nam molestie gravida dolor. Maecenas consectetur est bibendum, varius justo et, aliquet justo. Aliquam eget felis eget risus rhoncus pellentesque in at dui. Nunc rhoncus semper nibh vel pharetra. Duis nibh quam, bibendum nec consequat eget, egestas eget urna. Vivamus sit amet convallis dui. Sed a dui vel erat dapibus dictum ac eget elit. Curabitur mollis turpis vel lorem pretium consequat. Nunc elementum augue quis tempor sodales. Aenean eleifend risus nec tellus suscipit dictum. Nunc aliquet nec orci sit amet ultrices. Aliquam ultrices dolor at risus tristique, vitae feugiat justo hendrerit.</p><?php }} ?>
