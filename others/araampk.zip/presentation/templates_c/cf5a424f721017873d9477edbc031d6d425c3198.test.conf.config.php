<?php $_config_vars = array (
  'sections' => 
  array (
    'setup' => 
    array (
      'vars' => 
      array (
        'bold' => true,
      ),
    ),
  ),
  'vars' => 
  array (
    'site_title' => 'ARAAM.PK',
    'site_root' => 'http://localhost/araam',
    'cutoff_size' => 40,
  ),
); ?>