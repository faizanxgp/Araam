<?php /* Smarty version Smarty-3.1.15, created on 2016-03-30 09:32:22
         compiled from "D:\xampp\htdocs\araam\presentation\templates\contractorfooter.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2462456e0fb50073d62-16879926%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '851d3346fc529d0d7dbea67002a30c3293871bf8' => 
    array (
      0 => 'D:\\xampp\\htdocs\\araam\\presentation\\templates\\contractorfooter.tpl',
      1 => 1459254073,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2462456e0fb50073d62-16879926',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_56e0fb500aa873_85126799',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e0fb500aa873_85126799')) {function content_56e0fb500aa873_85126799($_smarty_tpl) {?>    <div class="row footer-row">
        <div class="col-md-12">
            <p>
                &copy; 2015 Araam.pk All Rights Reserved.
            </p>
        </div>
        
        
    </div>
</div>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="<?php echo $_smarty_tpl->getConfigVariable('site_root');?>
/web/js/jquery.js"></script>
<script src="<?php echo $_smarty_tpl->getConfigVariable('site_root');?>
/web/js/bootstrap.js"></script>
<!--<script src="offcanvas.js"></script>-->

<!-- Add fancyBox -->
<link rel="stylesheet" href="<?php echo $_smarty_tpl->getConfigVariable('site_root');?>
/web/fancybox/jquery.fancybox.css?v=2.1.5" type="text/css" media="screen" />
<script type="text/javascript" src="<?php echo $_smarty_tpl->getConfigVariable('site_root');?>
/web/fancybox/jquery.fancybox.pack.js?v=2.1.5"></script>
<script type="text/javascript">
	$(document).ready(function() {
		$(".fancybox").fancybox();
	});
</script>
<script src="<?php echo $_smarty_tpl->getConfigVariable('site_root');?>
/web/js/parsley.js" type="text/javascript" ></script>
</body>
</html><?php }} ?>
