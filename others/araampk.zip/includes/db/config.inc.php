<?php

//database server
define('DB_SERVER', "localhost");

//database login name
define('DB_USER', "dbuser");
//database login password
define('DB_PASS', "dbpass");

//database name
define('DB_DATABASE', "araampk");

//smart to define your table names also
define('TABLE_USERS', "users");
define('TABLE_NEWS', "news");
