<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$globalemailaddress = "araampakistan@gmail.com";

$gr_status = array(
    "active" => "Active",
    "inactive" => "Inactive"
);

$gr_contstatus = array(
    "applied" => "Applied",
    "active" => "Active",
    "inactive" => "Inactive",
    "rejected" => "Rejected"
);

$gr_reqstatus = array(
    "submitted" => "Submitted",
    "approved" => "Approved",
    "declined" => "Declined"
);

$gr_yesno = array(
    'yes' => "Yes",
    'no' => "No"
);

$gr_questiontype = array(
    'textbox' => 'Textbox',
    'textarea' => 'Textarea',
    'radio' => 'Radio',
    'checkbox' => 'Checkbox'
);

$gr_city = array(
    'Lahore' => 'Lahore',
    'Islamabad' => 'Islamabad',
    'Rawalpindi' => 'Rawalpindi'
);

$gr_quotetype = array(
    'Fixed' => 'Fixed',
    'Need more details or visit' => 'Need more details or visit'
);

$gr_contactpref = array(
'I travel to my professional' => 'I travel to my professional',
'My professional will travel to me' => 'My professional will travel to me',
'Phone or internet only' => 'Phone or internet only'
);

$gr_verified = array(
    '1' => 'Yes',
    '0' => 'No'
);

$gr_cancelreason = array(
    "I decided to do it myself or had a friend help" => "I decided to do it myself or had a friend help",
    "I hired a professional who's not on Araam" => "I hired a professional who's not on Araam",
    "I'm going to put it on hold or had a change of plans" => "I'm going to put it on hold or had a change of plans",
    "The quotes were not the right fit for me" => "The quotes were not the right fit for me"
    
);

$gr_review = array(
    '5' => 'Excellent',
    '4' => 'Very Good',
    '3' => 'Good',
    '2' => 'Average',
    '1' => 'Poor'
);