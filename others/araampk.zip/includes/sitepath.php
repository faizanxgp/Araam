<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
// an ending slash is required
// 
define('SITE_ROOT' , 'http://localhost/araam/');
//define('SITE_ROOT' , 'http://araam.pk/');
